var products = [{
    name: "Samsung Galaxy Tab A",
    image: "1.png",
    price: 1000
}, {
    name: "Máy tính bảng Mobell",
    image: "2.png",
    price: 1500
}, {
    name: "Điện thoại Iphone 8",
    image: "3.png",
    price: 2000
}, {
    name: "Điện thoại BlackBarry",
    image: "4.png",
    price: 3000
}, {
    name: "Điện thoại Realme 5",
    image: "5.png",
    price: 2000
}, {
    name: "Điện thoại Nokia 3.2",
    image: "6.png",
    price: 1700
}]